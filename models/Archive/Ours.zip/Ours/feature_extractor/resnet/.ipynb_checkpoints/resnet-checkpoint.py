# %load_ext autoreload
# %autoreload 2

import torch
import torch.nn as nn
from einops.layers.torch import Rearrange
import torchaudio
from copy import deepcopy

from .model.encoder import ResNetExtractor

MODEL_URL = "https://github.com/descriptinc/lyrebird-wav2clip/releases/download/v0.1.0-alpha/Wav2CLIP.pt"


def get_model(device="cpu", pretrained=True, frame_length=None, hop_length=None):
    if pretrained:
        checkpoint = torch.hub.load_state_dict_from_url(
            MODEL_URL, map_location=device, progress=True
        )
        model = ResNetExtractor(
            checkpoint=checkpoint,
            scenario="finetune", #frozen
            transform=True,
            frame_length=frame_length,
            hop_length=hop_length,
        )
    else:
        model = ResNetExtractor(
            scenario="supervise", frame_length=frame_length, hop_length=hop_length
        )
    model.to(device)
    return model


class ResNet(nn.Module):
    def __init__(self):
        super().__init__()
    
        self.model = get_model().encoder

    
    def preprocess(self, x, stage='test'):
        x = self.model.spectrogram(x)
        x = torch.log(x + 1e-7)
        x = (x - torch.mean(x)) / (torch.std(x) + 1e-9)
        return x
    
    def build_final_block(self):
        self.layer4_copy = deepcopy(self.model.layer4)

    def copy_final_stage(self):
        self.block4_copied = self.build_final_block()


    def get_main_stem(self):
        return [self.model.conv1, self.model.bn1, self.model.layer1, self.model.layer2,self.model.layer3]

    def get_content_stem(self):
        return [self.model.layer4]

    
    def get_hidden_state(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)

        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        return x

    def get_final_feature(self, x):
        x = self.model.layer4(x)
        
        x = self.model.avgpool(x)
        x = x.reshape(x.size(0), -1)

        return x
    
    def get_final_feature_copyed(self, x): 
        x = self.layer4_copy(x)
        
        x = self.model.avgpool(x)
        x = x.reshape(x.size(0), -1)

        return x
