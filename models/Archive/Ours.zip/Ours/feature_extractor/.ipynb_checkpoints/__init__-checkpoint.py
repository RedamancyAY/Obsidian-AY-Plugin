from .LCNN import LCNN
from .rawnet import RawNet2
from .resnet import ResNet

from .msfm.feature_extractor import FeatureExtractor2D as MSFM