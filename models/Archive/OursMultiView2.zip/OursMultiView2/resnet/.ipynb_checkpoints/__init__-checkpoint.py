import numpy as np
import torch

from .resnet import ResNet, convert_2d_to_1d