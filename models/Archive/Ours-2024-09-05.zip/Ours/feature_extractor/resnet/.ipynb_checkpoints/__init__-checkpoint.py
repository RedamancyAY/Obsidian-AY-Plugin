import numpy as np
import torch

from .resnet import ResNet