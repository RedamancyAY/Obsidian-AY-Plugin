from .functional import revgrad
from .module import GradientReversal